let rectangles = [];
let fr = 30;
let currentColor = 'blue';

var rectSpeed = 2.5

function setup() {
  createCanvas(400, 400);
  frameRate(fr);
  for (let i = 0; i < rectangles.length; i++) {
    fill(rectangles[i].color);
    rect(rectangles[i].x, rectangles[i].y, 50, 50);
  }
}

function draw() {
  background(220);
  
  for (let i = 0; i < rectangles.length; i++) {
    fill(rectangles[i].color);
    rect(rectangles[i].x, rectangles[i].y, 50, 50);
    
    if(rectangles[i].color === 'blue') {
      rectangles[i].x += rectSpeed;
    } else if (rectangles[i].color === 'red') {
      rectangles[i].y += rectSpeed;
    } else if (rectangles[i].color === 'green') {
      rectangles[i].x += -rectSpeed;
      rectangles[i].y += -rectSpeed;
    }
    if (rectangles[i].x > width) rectangles[i].x = -50;
    if (rectangles[i].x < -50) rectangles[i].x = width;
    if (rectangles[i].y > height) rectangles[i].y = -50;
    if (rectangles[i].y < -50) rectangles[i].y = height;
  }
}


function mouseClicked() {
  rectangles.push({ x: mouseX, y: mouseY, color: currentColor });
}

function keyPressed() {
  if (key === 'R' || key === 'r') {
    currentColor = 'red';
  } else if (key === 'G' || key === 'g') {
    currentColor = 'green';
  } else if (key === 'B' || key === 'b') {
    currentColor = 'blue';
  }
}