class Module {
  constructor(xOff, yOff, x, y, speed, unit) {
    this.xOff = xOff;
    this.yOff = yOff;
    this.x = x;
    this.y = y;
    this.speed = speed;
    this.unit = unit;
    this.xDir = 1;
    this.yDir = 1;
  }

  update() {
    this.x = this.x + this.speed * this.xDir;
    if (this.x >= this.unit || this.x <= 0) {
      this.xDir *= -1;
      this.x = this.x + 1 * this.xDir;
      this.y = this.y + 1 * this.yDir;
    }
    if (this.y >= this.unit || this.y <= 0) {
      this.yDir *= -1;
      this.y = this.y + 1 * this.yDir;
    }
  }

  draw() {
    fill(100, 50, 0);
    rect(this.xOff + this.x - a*0.0375, this.yOff + this.y - a/5, a*0.075, a/10);
    fill(255, 150, 0);
    ellipse(this.xOff + this.x, this.yOff + this.y, a/4.5, a*0.3);
    ellipse(this.xOff + this.x - a/10, this.yOff + this.y, a/5, a*0.27);
    ellipse(this.xOff + this.x + a/10, this.yOff + this.y, a/5, a*0.27);
    fill(0);
    triangle(
      this.xOff + this.x - a*0.075, this.yOff + this.y - a*0.075,
      this.xOff + this.x - a/10, this.yOff + this.y - a/40,
      this.xOff + this.x - a/20, this.yOff + this.y - a/40
    );
    triangle(
      this.xOff + this.x + a*0.075, this.yOff + this.y - a*0.075,
      this.xOff + this.x + a/10, this.yOff + this.y - a/40,
      this.xOff + this.x + a/20, this.yOff + this.y - a/40
    );
    beginShape();
      vertex(this.xOff + this.x - a/8, this.yOff + this.y);
      vertex(this.xOff + this.x - a*0.075, this.yOff + this.y + a*0.075);
      vertex(this.xOff + this.x - a/16, this.yOff + this.y + a/25);
      vertex(this.xOff + this.x - a*0.0375, this.yOff + this.y + a*0.0875);
      vertex(this.xOff + this.x, this.yOff + this.y + a*0.0625);

      vertex(this.xOff + this.x + a*0.0375, this.yOff + this.y + a*0.0875);
      vertex(this.xOff + this.x + a*0.0625, this.yOff + this.y + a/25);
      vertex(this.xOff + this.x + a*0.075, this.yOff + this.y + a*0.075);
      vertex(this.xOff + this.x + a/8, this.yOff + this.y);

      vertex(this.xOff + this.x + a*0.075, this.yOff + this.y + a/40);
      vertex(this.xOff + this.x + a/20, this.yOff + this.y);
      vertex(this.xOff + this.x, this.yOff + this.y + a/40);

      vertex(this.xOff + this.x - a/20, this.yOff + this.y);
      vertex(this.xOff + this.x - a*0.075, this.yOff + this.y + a/40);
      vertex(this.xOff + this.x - a/8, this.yOff + this.y);
    endShape();
  }
}

var a = 100;
let unit = a;
let count;
let mods = [];

function setup() {
  createCanvas(800, 800);
  noStroke();
  let wideCount = width / unit;
  let highCount = height / unit;
  count = wideCount * highCount;

  let index = 0;
  for (let y = 0; y < highCount; y++) {
    for (let x = 0; x < wideCount; x++) {
      mods[index++] = new Module(
        x * unit,
        y * unit,
        unit / 2,
        unit / 2,
        random(0.05, 0.8),
        unit
      );
    }
  }
}

function draw() {
  background(0);
  for (let i = 0; i < count; i++) {
    mods[i].update();
    mods[i].draw();
  }
}