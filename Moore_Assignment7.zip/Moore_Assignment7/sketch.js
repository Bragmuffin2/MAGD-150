let squares = [];

function setup() {
  createCanvas(400, 750);
  for (let i = 0; i < 16; i++) {
    squares.push(new Square(random(width), random(height), random(-3, 3), random(-3, 3), random(0.5, 1.5)));
  }
}

function draw() {
  background(220);

  for (let i = 0; i < squares.length; i++) {
    squares[i].move();
    squares[i].display();
    squares[i].printCoordinates();
  }

  if (mouseIsPressed) {
    moveSquaresToMouse();
  }
}

function moveSquaresToMouse() {
  for (let i = 0; i < squares.length; i++) {
    const speedX = (mouseX - squares[i].x) / 10;
    const speedY = (mouseY - squares[i].y) / 10;
    
    squares[i].x += speedX;
    squares[i].y += speedY;
  }
}

class Square {
  constructor(x, y, speedX, speedY, scale) {
    this.x = x;
    this.y = y;
    this.speedX = speedX;
    this.speedY = speedY;
    this.side = 30;
    this.rotation = 0;
    this.scale = scale;
  }

  move() {
    this.x += this.speedX;
    this.y += this.speedY;
   
    if (this.x <= 0 || this.x >= width) {
      this.speedX *= -1;
    }
    if (this.y <= 0 || this.y >= height) {
      this.speedY *= -1;
    }
  }

  display() {
    push();
    
    this.rotation = random(TWO_PI);
    translate(this.x, this.y);
    rotate(this.rotation);
    scale(this.scale);
    rectMode(CENTER);
    fill(255, 0, 0);
    rect(0, 0, this.side, this.side);

    pop();
  }

  printCoordinates() {
    push();
    fill(0);
    text(`x: ${Math.floor(this.x)}, y: ${Math.floor(this.y)}`, this.x + 15, this.y + 20);
    pop();
  }
}